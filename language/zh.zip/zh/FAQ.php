<?php
// Translated into English by Yaro2709;
// All rights reserved from 2020;
// Company 1367.

$LNG['faq_overview'] = "常见问题解答";
$LNG['questions'] = array();
$LNG['questions'][1]['category'] = '';
$LNG['questions'][1][1]['title'] = '';
$LNG['questions'][1][1]['body'] = '';

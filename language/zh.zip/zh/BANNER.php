<?php
// Translated into English by Yaro2709;
// All rights reserved from 2020;
// Company 1367.
 
$LNG['ub_points']                                      = '积分';
$LNG['ub_fights']                                      = '战斗';
$LNG['ub_quote']                                       = '引用';
$LNG['ub_rank']                                        = '排名';